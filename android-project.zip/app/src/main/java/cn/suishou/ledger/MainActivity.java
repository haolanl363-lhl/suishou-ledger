package cn.suishou.ledger;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.widget.Toast;
import android.view.View;
import android.view.WindowInsets;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> fileCallback;
 private String pendingFile;
 private static final int IMPORT=21, EXPORT=22;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  web=new WebView(this); setContentView(web);
  web.setOnApplyWindowInsetsListener((v,insets)->{if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);}else{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());}return insets;});
  web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(true);
  web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  web.addJavascriptInterface(new Object(){@JavascriptInterface public void saveFile(String text,String filename,String mime){if(text.length()>30000000)return;runOnUiThread(()->{if(pendingFile!=null){Toast.makeText(MainActivity.this,"请先完成当前导出",Toast.LENGTH_SHORT).show();return;}pendingFile=text;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime.startsWith("text/csv")?"text/csv":"application/json");i.putExtra(Intent.EXTRA_TITLE,filename);startActivityForResult(i,EXPORT);});}},"LedgerAndroid");
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){Uri u=r.getUrl();if("https".equals(u.getScheme())&&"suishou-ledger.onrender.com".equals(u.getHost()))return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){Toast.makeText(MainActivity.this,"无法打开该链接",Toast.LENGTH_SHORT).show();}return true;}
   @Override public void onPageFinished(WebView v,String url){if(url.startsWith("https://suishou-ledger.onrender.com/"))v.evaluateJavascript("if(typeof download==='function'){download=function(text,name,mime){LedgerAndroid.saveFile(text,name,mime)}}",null);}
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onJsConfirm(WebView v,String url,String message,JsResult result){new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("确定",(d,w)->result.confirm()).setNegativeButton("取消",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
   @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");try{startActivityForResult(i,IMPORT);return true;}catch(Exception e){fileCallback=null;cb.onReceiveValue(null);return true;}}});
  if(state==null||web.restoreState(state)==null)web.loadUrl("https://suishou-ledger.onrender.com/");
 }
 @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);web.saveState(out);}
 @Override protected void onActivityResult(int request,int result,Intent intent){super.onActivityResult(request,result,intent);Uri uri=intent==null?null:intent.getData();if(request==IMPORT&&fileCallback!=null){fileCallback.onReceiveValue(result==RESULT_OK&&uri!=null?new Uri[]{uri}:null);fileCallback=null;}if(request==EXPORT){if(result==RESULT_OK&&uri!=null&&pendingFile!=null){try(OutputStream os=getContentResolver().openOutputStream(uri)){if(os==null)throw new java.io.IOException();os.write(pendingFile.getBytes(StandardCharsets.UTF_8));Toast.makeText(this,"备份已保存",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"保存失败，请重试",Toast.LENGTH_LONG).show();}}pendingFile=null;}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){if(fileCallback!=null)fileCallback.onReceiveValue(null);web.removeJavascriptInterface("LedgerAndroid");web.destroy();super.onDestroy();}
}
